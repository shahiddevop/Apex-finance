const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'db.json');

app.use(cors());
app.use(express.json());
app.use(express.static(__dirname)); // Serve static files (index.html, styles.css, app.js)

// Password hashing utility
function hashPassword(password) {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Read database file helper
function readDB() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      // Re-create default database if deleted
      writeDB(getDefaultDB());
      return getDefaultDB();
    }
    const rawData = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(rawData);
  } catch (error) {
    console.error('Error reading database file, resetting to default:', error);
    const defaults = getDefaultDB();
    writeDB(defaults);
    return defaults;
  }
}

// Write database file helper
function writeDB(data) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
    return true;
  } catch (error) {
    console.error('Error writing database file:', error);
    return false;
  }
}

// System defaults configuration
function getDefaultDB() {
  return {
    users: [
      {
        id: "u1",
        username: "demo",
        passwordHash: "ef92b778bafe4cc161592dcfd7c61917313935221b79d47a8e26a7a72666a401", // "password123"
        fullName: "Demo User"
      }
    ],
    transactions: [
      {
        id: "t1",
        userId: "u1",
        amount: 3500.00,
        type: "income",
        category: "Salary",
        date: "2026-05-01",
        description: "Monthly Salary from Acme Corp"
      },
      {
        id: "t2",
        userId: "u1",
        amount: 1200.00,
        type: "expense",
        category: "Rent",
        date: "2026-05-02",
        description: "Apartment Rent Payment"
      },
      {
        id: "t3",
        userId: "u1",
        amount: 165.50,
        type: "expense",
        category: "Food",
        date: "2026-05-04",
        description: "Weekly Groceries at Trader Joe's"
      },
      {
        id: "t4",
        userId: "u1",
        amount: 450.00,
        type: "income",
        category: "Freelance",
        date: "2026-05-10",
        description: "UI Design Consult Work"
      },
      {
        id: "t5",
        userId: "u1",
        amount: 89.90,
        type: "expense",
        category: "Utilities",
        date: "2026-05-12",
        description: "Electricity Bill Payment"
      },
      {
        id: "t6",
        userId: "u1",
        amount: 75.00,
        type: "expense",
        category: "Shopping",
        date: "2026-05-15",
        description: "New Summer Clothes"
      },
      {
        id: "t7",
        userId: "u1",
        amount: 42.00,
        type: "expense",
        category: "Transport",
        date: "2026-05-18",
        description: "Gas Station Fill-up"
      },
      {
        id: "t8",
        userId: "u1",
        amount: 35.00,
        type: "expense",
        category: "Entertainment",
        date: "2026-05-22",
        description: "Cinema & Popcorn Night"
      },
      {
        id: "t9",
        userId: "u1",
        amount: 3500.00,
        type: "income",
        category: "Salary",
        date: "2026-06-01",
        description: "Monthly Salary from Acme Corp"
      },
      {
        id: "t10",
        userId: "u1",
        amount: 1200.00,
        type: "expense",
        category: "Rent",
        date: "2026-06-02",
        description: "Apartment Rent Payment"
      },
      {
        id: "t11",
        userId: "u1",
        amount: 142.30,
        type: "expense",
        category: "Food",
        date: "2026-06-03",
        description: "Supermarket Weekly Grocery Haul"
      },
      {
        id: "t12",
        userId: "u1",
        amount: 600.00,
        type: "income",
        category: "Freelance",
        date: "2026-06-04",
        description: "Web Development Project Milestone"
      },
      {
        id: "t13",
        userId: "u1",
        amount: 115.00,
        type: "expense",
        category: "Utilities",
        date: "2026-06-04",
        description: "High-speed Internet & Cell Service"
      }
    ],
    categories: [
      { name: "Salary", type: "income", color: "#10b981", icon: "fa-briefcase" },
      { name: "Freelance", type: "income", color: "#06b6d4", icon: "fa-laptop-code" },
      { name: "Investments", type: "income", color: "#8b5cf6", icon: "fa-chart-line" },
      { name: "Other Income", type: "income", color: "#14b8a6", icon: "fa-coins" },
      { name: "Food", type: "expense", color: "#f59e0b", icon: "fa-utensils" },
      { name: "Rent", type: "expense", color: "#ef4444", icon: "fa-house" },
      { name: "Utilities", type: "expense", color: "#3b82f6", icon: "fa-bolt" },
      { name: "Entertainment", type: "expense", color: "#ec4899", icon: "fa-film" },
      { name: "Shopping", type: "expense", color: "#d946ef", icon: "fa-bag-shopping" },
      { name: "Transport", type: "expense", color: "#0ea5e9", icon: "fa-car" },
      { name: "Healthcare", type: "expense", color: "#e11d48", icon: "fa-heart-pulse" },
      { name: "Education", type: "expense", color: "#f97316", icon: "fa-graduation-cap" },
      { name: "Travel", type: "expense", color: "#84cc16", icon: "fa-plane" },
      { name: "Miscellaneous", type: "expense", color: "#64748b", icon: "fa-circle-question" }
    ]
  };
}

// API Endpoints

// 1. User Registration
app.post('/api/auth/register', (req, res) => {
  const { username, password, fullName } = req.body;
  if (!username || !password || !fullName) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  const db = readDB();
  const lowerUsername = username.toLowerCase();

  // Check if username already exists
  if (db.users.find(u => u.username.toLowerCase() === lowerUsername)) {
    return res.status(400).json({ error: 'Username is already taken' });
  }

  const newUser = {
    id: 'u_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    username: username,
    passwordHash: hashPassword(password),
    fullName: fullName
  };

  db.users.push(newUser);
  writeDB(db);

  // Return user info, omit password hash
  const { passwordHash, ...userResponse } = newUser;
  res.status(201).json(userResponse);
});

// 2. User Login
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password are required' });
  }

  const db = readDB();
  const lowerUsername = username.toLowerCase();
  const user = db.users.find(u => u.username.toLowerCase() === lowerUsername);

  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  const { passwordHash, ...userResponse } = user;
  res.json(userResponse);
});

// 2b. Reset Password
app.post('/api/auth/reset-password', (req, res) => {
  const { username, newPassword } = req.body;
  if (!username || !newPassword) {
    return res.status(400).json({ error: 'Username and new password are required' });
  }

  const db = readDB();
  const lowerUsername = username.toLowerCase();
  const userIdx = db.users.findIndex(u => u.username.toLowerCase() === lowerUsername);

  if (userIdx === -1) {
    return res.status(404).json({ error: 'Username not found' });
  }

  db.users[userIdx].passwordHash = hashPassword(newPassword);
  writeDB(db);

  res.json({ message: 'Password reset successfully' });
});

// 3. Get User Transactions
app.get('/api/transactions', (req, res) => {
  const userId = req.headers['user-id'] || req.query.userId;
  if (!userId) {
    return res.status(400).json({ error: 'User-ID header or query parameter is required' });
  }

  const db = readDB();
  const userTransactions = db.transactions.filter(t => t.userId === userId);
  res.json(userTransactions);
});

// 4. Create Transaction
app.post('/api/transactions', (req, res) => {
  const userId = req.headers['user-id'];
  const { amount, type, category, date, description } = req.body;

  if (!userId) {
    return res.status(400).json({ error: 'User-ID header is required' });
  }
  if (amount === undefined || !type || !category || !date) {
    return res.status(400).json({ error: 'Missing required transaction fields' });
  }

  const db = readDB();
  const newTransaction = {
    id: 't_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    userId,
    amount: parseFloat(amount),
    type,
    category,
    date,
    description: description || ''
  };

  db.transactions.push(newTransaction);
  writeDB(db);

  res.status(201).json(newTransaction);
});

// 5. Update Transaction
app.put('/api/transactions/:id', (req, res) => {
  const userId = req.headers['user-id'];
  const { id } = req.params;
  const { amount, type, category, date, description } = req.body;

  if (!userId) {
    return res.status(400).json({ error: 'User-ID header is required' });
  }

  const db = readDB();
  const txIndex = db.transactions.findIndex(t => t.id === id);

  if (txIndex === -1) {
    return res.status(404).json({ error: 'Transaction not found' });
  }

  const transaction = db.transactions[txIndex];
  if (transaction.userId !== userId) {
    return res.status(403).json({ error: 'Unauthorized to modify this transaction' });
  }

  // Update transaction properties
  if (amount !== undefined) transaction.amount = parseFloat(amount);
  if (type) transaction.type = type;
  if (category) transaction.category = category;
  if (date) transaction.date = date;
  if (description !== undefined) transaction.description = description;

  db.transactions[txIndex] = transaction;
  writeDB(db);

  res.json(transaction);
});

// 6. Delete Transaction
app.delete('/api/transactions/:id', (req, res) => {
  const userId = req.headers['user-id'];
  const { id } = req.params;

  if (!userId) {
    return res.status(400).json({ error: 'User-ID header is required' });
  }

  const db = readDB();
  const txIndex = db.transactions.findIndex(t => t.id === id);

  if (txIndex === -1) {
    return res.status(404).json({ error: 'Transaction not found' });
  }

  const transaction = db.transactions[txIndex];
  if (transaction.userId !== userId) {
    return res.status(403).json({ error: 'Unauthorized to delete this transaction' });
  }

  db.transactions.splice(txIndex, 1);
  writeDB(db);

  res.json({ message: 'Transaction deleted successfully', id });
});

// 7. Get Categories
app.get('/api/categories', (req, res) => {
  const userId = req.headers['user-id'] || req.query.userId;
  const db = readDB();

  // Return standard categories + user specific custom categories if any
  const userCategories = db.categories.filter(c => !c.userId || c.userId === userId);
  res.json(userCategories);
});

// 8. Create Custom Category
app.post('/api/categories', (req, res) => {
  const userId = req.headers['user-id'];
  const { name, type, color, icon } = req.body;

  if (!userId) {
    return res.status(400).json({ error: 'User-ID header is required' });
  }
  if (!name || !type || !color || !icon) {
    return res.status(400).json({ error: 'Missing required category fields' });
  }

  const db = readDB();
  
  // Check duplicate
  const lowerName = name.toLowerCase();
  const exists = db.categories.some(c => c.name.toLowerCase() === lowerName && (!c.userId || c.userId === userId));
  if (exists) {
    return res.status(400).json({ error: 'Category already exists' });
  }

  const newCategory = {
    name,
    type,
    color,
    icon,
    userId
  };

  db.categories.push(newCategory);
  writeDB(db);

  res.status(201).json(newCategory);
});

// Catch-all route to serve the HTML file (helps client-side routing if added later)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
  console.log(`Open http://localhost:${PORT} in your browser to start tracking your finances.`);
});
